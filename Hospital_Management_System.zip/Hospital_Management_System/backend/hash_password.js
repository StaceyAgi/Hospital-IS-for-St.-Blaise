// hashPassword.js
const bcrypt = require('bcryptjs');

// Password to hash
const password = 'patient123'; // Change this to your desired password
const saltRounds = 10;

bcrypt.hash(password, saltRounds, (err, hash) => {
    if (err) {
        console.error('Error hashing password:', err);
        return;
    }
    console.log('Password:', password);
    console.log('Hashed Password:', hash);
    
    // Verify the hash
    bcrypt.compare(password, hash, (err, result) => {
        if (err) {
            console.error('Error verifying hash:', err);
            return;
        }
        console.log('Password verification:', result);
    });
});
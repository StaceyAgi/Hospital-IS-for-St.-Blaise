const { body, validationResult } = require('express-validator');

const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      details: errors.array()
    });
  }
  next();
};

// Auth validations
const validateLogin = [
  body('email').isEmail().normalizeEmail(),
  body('password').isLength({ min: 6 }),
  handleValidationErrors
];

const validatePatient = [
  body('first_name').notEmpty().trim(),
  body('last_name').notEmpty().trim(),
  body('date_of_birth').isDate(),
  body('gender').isIn(['Male', 'Female', 'Other']),
  body('phone_number').notEmpty(),
  body('email').isEmail().normalizeEmail(),
  handleValidationErrors
];

const validateAppointment = [
  body('patient_id').isUUID(),
  body('doctor_id').isUUID(),
  body('appointment_date').isDate(),
  body('appointment_time').matches(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/),
  body('reason').optional().trim(),
  handleValidationErrors
];

const validateMedicalRecord = [
  body('patient_id').isUUID(),
  body('doctor_id').isUUID(),
  body('diagnosis').optional().trim(),
  body('symptoms').optional().trim(),
  body('treatment').optional().trim(),
  handleValidationErrors
];

module.exports = {
  validateLogin,
  validatePatient,
  validateAppointment,
  validateMedicalRecord,
  handleValidationErrors
};
module.exports = {
  ROLES: {
    ADMIN: 'admin',
    DOCTOR: 'doctor',
    NURSE: 'nurse',
    RECEPTIONIST: 'receptionist',
    PATIENT: 'patient'
  },
  
  APPOINTMENT_STATUS: {
    SCHEDULED: 'scheduled',
    COMPLETED: 'completed',
    CANCELLED: 'cancelled',
    NO_SHOW: 'no_show'
  },
  
  ADMISSION_STATUS: {
    ADMITTED: 'admitted',
    DISCHARGED: 'discharged',
    TRANSFERRED: 'transferred'
  },
  
  BILL_STATUS: {
    PENDING: 'pending',
    PAID: 'paid',
    PARTIAL: 'partial',
    OVERDUE: 'overdue'
  },
  
  ROOM_TYPES: {
    GENERAL: 'general',
    PRIVATE: 'private',
    ICU: 'icu',
    EMERGENCY: 'emergency',
    OPERATION_THEATER: 'operation_theater'
  }
};
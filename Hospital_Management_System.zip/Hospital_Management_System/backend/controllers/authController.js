const db = require('../config/database');
const { comparePassword, generateToken, formatResponse } = require('../utils/helpers');

const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    // Find user by email
    const userResult = await db.query(
      `SELECT u.user_id, u.email, u.password_hash, u.role, u.is_active,
              COALESCE(s.staff_id, p.patient_id) as profile_id,
              COALESCE(s.first_name, p.first_name) as first_name,
              COALESCE(s.last_name, p.last_name) as last_name
       FROM users u
       LEFT JOIN staff s ON u.user_id = s.user_id
       LEFT JOIN patients p ON u.user_id = p.user_id
       WHERE u.email = $1`,
      [email]
    );

    if (userResult.rows.length === 0) {
      return res.status(401).json(
        formatResponse(false, null, 'Invalid credentials')
      );
    }

    const user = userResult.rows[0];

    if (!user.is_active) {
      return res.status(401).json(
        formatResponse(false, null, 'Account is deactivated')
      );
    }

    // Check password
    const isPasswordValid = await comparePassword(password, user.password_hash);
    if (!isPasswordValid) {
      return res.status(401).json(
        formatResponse(false, null, 'Invalid credentials')
      );
    }

    // Generate token
    const token = generateToken(user.user_id);

    // Return user data without password
    const userData = {
      user_id: user.user_id,
      email: user.email,
      role: user.role,
      first_name: user.first_name,
      last_name: user.last_name,
      profile_id: user.profile_id
    };

    res.json(formatResponse(true, {
      user: userData,
      token
    }, 'Login successful'));

  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const getProfile = async (req, res) => {
  try {
    const userId = req.user.user_id;

    const result = await db.query(
      `SELECT u.user_id, u.email, u.role, u.created_at,
              COALESCE(s.staff_id, p.patient_id) as profile_id,
              COALESCE(s.first_name, p.first_name) as first_name,
              COALESCE(s.last_name, p.last_name) as last_name,
              COALESCE(s.phone_number, p.phone_number) as phone_number,
              COALESCE(s.date_of_birth, p.date_of_birth) as date_of_birth,
              COALESCE(s.gender, p.gender) as gender,
              s.specialization, s.department, s.qualification,
              p.blood_type, p.allergies, p.medical_history,
              p.emergency_contact_name, p.emergency_contact_phone
       FROM users u
       LEFT JOIN staff s ON u.user_id = s.user_id
       LEFT JOIN patients p ON u.user_id = p.user_id
       WHERE u.user_id = $1`,
      [userId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json(
        formatResponse(false, null, 'User not found')
      );
    }

    res.json(formatResponse(true, result.rows[0], 'Profile retrieved successfully'));

  } catch (error) {
    console.error('Get profile error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const changePassword = async (req, res) => {
  try {
    const userId = req.user.user_id;
    const { currentPassword, newPassword } = req.body;

    // Get current password hash
    const userResult = await db.query(
      'SELECT password_hash FROM users WHERE user_id = $1',
      [userId]
    );

    const isCurrentPasswordValid = await comparePassword(
      currentPassword, 
      userResult.rows[0].password_hash
    );

    if (!isCurrentPasswordValid) {
      return res.status(400).json(
        formatResponse(false, null, 'Current password is incorrect')
      );
    }

    // Hash new password
    const newHashedPassword = await hashPassword(newPassword);

    // Update password
    await db.query(
      'UPDATE users SET password_hash = $1, updated_at = CURRENT_TIMESTAMP WHERE user_id = $2',
      [newHashedPassword, userId]
    );

    res.json(formatResponse(true, null, 'Password changed successfully'));

  } catch (error) {
    console.error('Change password error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

module.exports = {
  login,
  getProfile,
  changePassword
};
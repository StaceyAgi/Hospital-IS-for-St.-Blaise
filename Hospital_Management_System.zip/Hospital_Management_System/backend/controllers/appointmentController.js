const db = require('../config/database');
const { formatResponse } = require('../utils/helpers');

const getAllAppointments = async (req, res) => {
  try {
    const { page = 1, limit = 10, status, date, doctor_id } = req.query;
    const offset = (page - 1) * limit;

    let query = `
      SELECT a.*, 
             p.first_name as patient_first_name, p.last_name as patient_last_name,
             p.phone_number as patient_phone,
             s.first_name as doctor_first_name, s.last_name as doctor_last_name,
             s.specialization
      FROM appointments a
      JOIN patients p ON a.patient_id = p.patient_id
      JOIN staff s ON a.doctor_id = s.staff_id
      WHERE 1=1
    `;
    let countQuery = `
      SELECT COUNT(*) 
      FROM appointments a
      WHERE 1=1
    `;
    const params = [];
    let paramCount = 0;

    if (status) {
      paramCount++;
      query += ` AND a.status = $${paramCount}`;
      countQuery += ` AND a.status = $${paramCount}`;
      params.push(status);
    }

    if (date) {
      paramCount++;
      query += ` AND a.appointment_date = $${paramCount}`;
      countQuery += ` AND a.appointment_date = $${paramCount}`;
      params.push(date);
    }

    if (doctor_id) {
      paramCount++;
      query += ` AND a.doctor_id = $${paramCount}`;
      countQuery += ` AND a.doctor_id = $${paramCount}`;
      params.push(doctor_id);
    }

    paramCount++;
    query += ` ORDER BY a.appointment_date, a.appointment_time 
               LIMIT $${paramCount} OFFSET $${paramCount + 1}`;
    params.push(limit, offset);

    const [appointmentsResult, countResult] = await Promise.all([
      db.query(query, params),
      db.query(countQuery, params.slice(0, -2))
    ]);

    const totalAppointments = parseInt(countResult.rows[0].count);
    const totalPages = Math.ceil(totalAppointments / limit);

    res.json(formatResponse(true, {
      appointments: appointmentsResult.rows,
      pagination: {
        currentPage: parseInt(page),
        totalPages,
        totalAppointments,
        hasNext: page < totalPages,
        hasPrev: page > 1
      }
    }, 'Appointments retrieved successfully'));

  } catch (error) {
    console.error('Get appointments error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const getAppointmentById = async (req, res) => {
  try {
    const { id } = req.params;

    const result = await db.query(
      `SELECT a.*, 
              p.first_name as patient_first_name, p.last_name as patient_last_name,
              p.phone_number as patient_phone, p.email as patient_email,
              s.first_name as doctor_first_name, s.last_name as doctor_last_name,
              s.specialization, s.department
       FROM appointments a
       JOIN patients p ON a.patient_id = p.patient_id
       JOIN staff s ON a.doctor_id = s.staff_id
       WHERE a.appointment_id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json(
        formatResponse(false, null, 'Appointment not found')
      );
    }

    res.json(formatResponse(true, result.rows[0], 'Appointment retrieved successfully'));

  } catch (error) {
    console.error('Get appointment error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const createAppointment = async (req, res) => {
  try {
    const {
      patient_id, doctor_id, appointment_date, appointment_time,
      reason, notes
    } = req.body;

    // Check if doctor is available at that time
    const conflictCheck = await db.query(
      `SELECT appointment_id FROM appointments 
       WHERE doctor_id = $1 AND appointment_date = $2 AND appointment_time = $3 
       AND status != 'cancelled'`,
      [doctor_id, appointment_date, appointment_time]
    );

    if (conflictCheck.rows.length > 0) {
      return res.status(400).json(
        formatResponse(false, null, 'Doctor is not available at this time')
      );
    }

    const result = await db.query(
      `INSERT INTO appointments (
        patient_id, doctor_id, appointment_date, appointment_time,
        reason, notes
      ) VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING *`,
      [patient_id, doctor_id, appointment_date, appointment_time, reason, notes]
    );

    res.status(201).json(
      formatResponse(true, result.rows[0], 'Appointment created successfully')
    );

  } catch (error) {
    console.error('Create appointment error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const updateAppointment = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      appointment_date, appointment_time, status, reason, notes
    } = req.body;

    const result = await db.query(
      `UPDATE appointments 
       SET appointment_date = $1, appointment_time = $2, status = $3,
           reason = $4, notes = $5, updated_at = CURRENT_TIMESTAMP
       WHERE appointment_id = $6
       RETURNING *`,
      [appointment_date, appointment_time, status, reason, notes, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json(
        formatResponse(false, null, 'Appointment not found')
      );
    }

    res.json(formatResponse(true, result.rows[0], 'Appointment updated successfully'));

  } catch (error) {
    console.error('Update appointment error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const getDoctorAppointments = async (req, res) => {
  try {
    const { doctor_id } = req.params;
    const { date } = req.query;

    let query = `
      SELECT a.*, 
             p.first_name as patient_first_name, p.last_name as patient_last_name,
             p.phone_number as patient_phone
      FROM appointments a
      JOIN patients p ON a.patient_id = p.patient_id
      WHERE a.doctor_id = $1
    `;
    const params = [doctor_id];

    if (date) {
      query += ` AND a.appointment_date = $2`;
      params.push(date);
    }

    query += ` ORDER BY a.appointment_date, a.appointment_time`;

    const result = await db.query(query, params);

    res.json(formatResponse(true, result.rows, 'Doctor appointments retrieved successfully'));

  } catch (error) {
    console.error('Get doctor appointments error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const getAppointmentStats = async (req, res) => {
  try {
    const statsQuery = `
      SELECT 
        COUNT(*) as total_appointments,
        COUNT(CASE WHEN status = 'scheduled' THEN 1 END) as scheduled,
        COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed,
        COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancelled,
        COUNT(CASE WHEN status = 'no_show' THEN 1 END) as no_show,
        COUNT(CASE WHEN appointment_date = CURRENT_DATE THEN 1 END) as today_appointments
      FROM appointments
    `;

    const result = await db.query(statsQuery);
    
    res.json(formatResponse(true, result.rows[0], 'Appointment stats retrieved successfully'));

  } catch (error) {
    console.error('Get appointment stats error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

module.exports = {
  getAllAppointments,
  getAppointmentById,
  createAppointment,
  updateAppointment,
  getDoctorAppointments,
  getAppointmentStats
};
const db = require('../config/database');
const { formatResponse } = require('../utils/helpers');

const getAllAdmissions = async (req, res) => {
  try {
    const { status, page = 1, limit = 10 } = req.query;
    const offset = (page - 1) * limit;

    let query = `
      SELECT a.*, 
             p.first_name as patient_first_name, p.last_name as patient_last_name,
             r.room_number, r.room_type,
             s.first_name as doctor_first_name, s.last_name as doctor_last_name
      FROM admissions a
      JOIN patients p ON a.patient_id = p.patient_id
      LEFT JOIN rooms r ON a.room_id = r.room_id
      LEFT JOIN staff s ON a.assigned_doctor_id = s.staff_id
      WHERE 1=1
    `;
    let countQuery = `
      SELECT COUNT(*) 
      FROM admissions a
      WHERE 1=1
    `;
    const params = [];
    let paramCount = 0;

    if (status) {
      paramCount++;
      query += ` AND a.status = $${paramCount}`;
      countQuery += ` AND a.status = $${paramCount}`;
      params.push(status);
    }

    paramCount++;
    query += ` ORDER BY a.admission_date DESC LIMIT $${paramCount} OFFSET $${paramCount + 1}`;
    params.push(limit, offset);

    const [admissionsResult, countResult] = await Promise.all([
      db.query(query, params),
      db.query(countQuery, params.slice(0, -2))
    ]);

    const totalAdmissions = parseInt(countResult.rows[0].count);
    const totalPages = Math.ceil(totalAdmissions / limit);

    res.json(formatResponse(true, {
      admissions: admissionsResult.rows,
      pagination: {
        currentPage: parseInt(page),
        totalPages,
        totalAdmissions,
        hasNext: page < totalPages,
        hasPrev: page > 1
      }
    }, 'Admissions retrieved successfully'));

  } catch (error) {
    console.error('Get admissions error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const getAdmissionById = async (req, res) => {
  try {
    const { id } = req.params;

    const result = await db.query(
      `SELECT a.*, 
              p.first_name as patient_first_name, p.last_name as patient_last_name,
              p.phone_number as patient_phone, p.email as patient_email,
              r.room_number, r.room_type, r.price_per_day,
              s.first_name as doctor_first_name, s.last_name as doctor_last_name,
              s.specialization
       FROM admissions a
       JOIN patients p ON a.patient_id = p.patient_id
       LEFT JOIN rooms r ON a.room_id = r.room_id
       LEFT JOIN staff s ON a.assigned_doctor_id = s.staff_id
       WHERE a.admission_id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json(
        formatResponse(false, null, 'Admission not found')
      );
    }

    res.json(formatResponse(true, result.rows[0], 'Admission retrieved successfully'));

  } catch (error) {
    console.error('Get admission error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const createAdmission = async (req, res) => {
  const client = await db.pool.connect();
  
  try {
    await client.query('BEGIN');

    const {
      patient_id, room_id, reason, assigned_doctor_id, notes
    } = req.body;

    // Check if room is available
    const roomCheck = await client.query(
      'SELECT is_available, current_occupancy, capacity FROM rooms WHERE room_id = $1',
      [room_id]
    );

    if (roomCheck.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json(
        formatResponse(false, null, 'Room not found')
      );
    }

    const room = roomCheck.rows[0];
    if (!room.is_available || room.current_occupancy >= room.capacity) {
      await client.query('ROLLBACK');
      return res.status(400).json(
        formatResponse(false, null, 'Room is not available')
      );
    }

    // Create admission
    const admissionResult = await client.query(
      `INSERT INTO admissions (patient_id, room_id, reason, assigned_doctor_id, notes)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [patient_id, room_id, reason, assigned_doctor_id, notes]
    );

    // Update room occupancy
    await client.query(
      'UPDATE rooms SET current_occupancy = current_occupancy + 1 WHERE room_id = $1',
      [room_id]
    );

    // Mark room as unavailable if full
    if (room.current_occupancy + 1 >= room.capacity) {
      await client.query(
        'UPDATE rooms SET is_available = false WHERE room_id = $1',
        [room_id]
      );
    }

    await client.query('COMMIT');

    res.status(201).json(
      formatResponse(true, admissionResult.rows[0], 'Patient admitted successfully')
    );

  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Create admission error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  } finally {
    client.release();
  }
};

const updateAdmission = async (req, res) => {
  try {
    const { id } = req.params;
    const { status, discharge_date, room_id, assigned_doctor_id, notes } = req.body;

    const result = await db.query(
      `UPDATE admissions 
       SET status = $1, discharge_date = $2, room_id = $3, 
           assigned_doctor_id = $4, notes = $5
       WHERE admission_id = $6
       RETURNING *`,
      [status, discharge_date, room_id, assigned_doctor_id, notes, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json(
        formatResponse(false, null, 'Admission not found')
      );
    }

    res.json(formatResponse(true, result.rows[0], 'Admission updated successfully'));

  } catch (error) {
    console.error('Update admission error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const dischargePatient = async (req, res) => {
  const client = await db.pool.connect();
  
  try {
    await client.query('BEGIN');

    const { id } = req.params;
    const { discharge_notes } = req.body;

    // Get admission details
    const admissionResult = await client.query(
      'SELECT * FROM admissions WHERE admission_id = $1',
      [id]
    );

    if (admissionResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json(
        formatResponse(false, null, 'Admission not found')
      );
    }

    const admission = admissionResult.rows[0];

    // Update admission status
    const updateResult = await client.query(
      `UPDATE admissions 
       SET status = 'discharged', discharge_date = CURRENT_TIMESTAMP, notes = $1
       WHERE admission_id = $2
       RETURNING *`,
      [discharge_notes, id]
    );

    // Update room occupancy if room exists
    if (admission.room_id) {
      await client.query(
        'UPDATE rooms SET current_occupancy = current_occupancy - 1 WHERE room_id = $1',
        [admission.room_id]
      );

      // Mark room as available if occupancy decreased
      const roomResult = await client.query(
        'SELECT capacity, current_occupancy FROM rooms WHERE room_id = $1',
        [admission.room_id]
      );

      if (roomResult.rows.length > 0) {
        const room = roomResult.rows[0];
        if (room.current_occupancy - 1 < room.capacity) {
          await client.query(
            'UPDATE rooms SET is_available = true WHERE room_id = $1',
            [admission.room_id]
          );
        }
      }
    }

    await client.query('COMMIT');

    res.json(formatResponse(true, updateResult.rows[0], 'Patient discharged successfully'));

  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Discharge patient error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  } finally {
    client.release();
  }
};

const getCurrentAdmissions = async (req, res) => {
  try {
    const result = await db.query(
      `SELECT a.*, 
              p.first_name as patient_first_name, p.last_name as patient_last_name,
              r.room_number, r.room_type,
              s.first_name as doctor_first_name, s.last_name as doctor_last_name
       FROM admissions a
       JOIN patients p ON a.patient_id = p.patient_id
       LEFT JOIN rooms r ON a.room_id = r.room_id
       LEFT JOIN staff s ON a.assigned_doctor_id = s.staff_id
       WHERE a.status = 'admitted'
       ORDER BY a.admission_date DESC`
    );

    res.json(formatResponse(true, result.rows, 'Current admissions retrieved successfully'));

  } catch (error) {
    console.error('Get current admissions error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

module.exports = {
  getAllAdmissions,
  getAdmissionById,
  createAdmission,
  updateAdmission,
  dischargePatient,
  getCurrentAdmissions
};
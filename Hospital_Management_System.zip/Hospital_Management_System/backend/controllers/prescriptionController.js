const db = require('../config/database');
const { formatResponse } = require('../utils/helpers');

const getPrescriptions = async (req, res) => {
  try {
    const { patient_id, record_id, page = 1, limit = 10 } = req.query;
    const offset = (page - 1) * limit;

    let query = `
      SELECT p.*, 
             mr.diagnosis,
             pat.first_name as patient_first_name, pat.last_name as patient_last_name,
             s.first_name as doctor_first_name, s.last_name as doctor_last_name
      FROM prescriptions p
      JOIN medical_records mr ON p.record_id = mr.record_id
      JOIN patients pat ON mr.patient_id = pat.patient_id
      JOIN staff s ON mr.doctor_id = s.staff_id
      WHERE p.is_active = true
    `;
    let countQuery = `
      SELECT COUNT(*) 
      FROM prescriptions p
      WHERE p.is_active = true
    `;
    const params = [];
    let paramCount = 0;

    if (patient_id) {
      paramCount++;
      query += ` AND mr.patient_id = $${paramCount}`;
      countQuery += ` AND mr.patient_id = $${paramCount}`;
      params.push(patient_id);
    }

    if (record_id) {
      paramCount++;
      query += ` AND p.record_id = $${paramCount}`;
      countQuery += ` AND p.record_id = $${paramCount}`;
      params.push(record_id);
    }

    paramCount++;
    query += ` ORDER BY p.prescribed_date DESC LIMIT $${paramCount} OFFSET $${paramCount + 1}`;
    params.push(limit, offset);

    const [prescriptionsResult, countResult] = await Promise.all([
      db.query(query, params),
      db.query(countQuery, params.slice(0, -2))
    ]);

    const totalPrescriptions = parseInt(countResult.rows[0].count);
    const totalPages = Math.ceil(totalPrescriptions / limit);

    res.json(formatResponse(true, {
      prescriptions: prescriptionsResult.rows,
      pagination: {
        currentPage: parseInt(page),
        totalPages,
        totalPrescriptions,
        hasNext: page < totalPages,
        hasPrev: page > 1
      }
    }, 'Prescriptions retrieved successfully'));

  } catch (error) {
    console.error('Get prescriptions error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const getPrescriptionById = async (req, res) => {
  try {
    const { id } = req.params;

    const result = await db.query(
      `SELECT p.*, 
              mr.diagnosis, mr.visit_date,
              pat.first_name as patient_first_name, pat.last_name as patient_last_name,
              pat.date_of_birth as patient_dob, pat.gender as patient_gender,
              s.first_name as doctor_first_name, s.last_name as doctor_last_name,
              s.specialization
       FROM prescriptions p
       JOIN medical_records mr ON p.record_id = mr.record_id
       JOIN patients pat ON mr.patient_id = pat.patient_id
       JOIN staff s ON mr.doctor_id = s.staff_id
       WHERE p.prescription_id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json(
        formatResponse(false, null, 'Prescription not found')
      );
    }

    res.json(formatResponse(true, result.rows[0], 'Prescription retrieved successfully'));

  } catch (error) {
    console.error('Get prescription error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const createPrescription = async (req, res) => {
  try {
    const {
      record_id, medication_name, dosage, frequency,
      duration, instructions
    } = req.body;

    const result = await db.query(
      `INSERT INTO prescriptions (
        record_id, medication_name, dosage, frequency,
        duration, instructions
      ) VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING *`,
      [record_id, medication_name, dosage, frequency, duration, instructions]
    );

    res.status(201).json(
      formatResponse(true, result.rows[0], 'Prescription created successfully')
    );

  } catch (error) {
    console.error('Create prescription error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const updatePrescription = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      medication_name, dosage, frequency, duration, instructions, is_active
    } = req.body;

    const result = await db.query(
      `UPDATE prescriptions 
       SET medication_name = $1, dosage = $2, frequency = $3,
           duration = $4, instructions = $5, is_active = $6
       WHERE prescription_id = $7
       RETURNING *`,
      [medication_name, dosage, frequency, duration, instructions, is_active, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json(
        formatResponse(false, null, 'Prescription not found')
      );
    }

    res.json(formatResponse(true, result.rows[0], 'Prescription updated successfully'));

  } catch (error) {
    console.error('Update prescription error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const getPatientPrescriptions = async (req, res) => {
  try {
    const { patient_id } = req.params;

    const result = await db.query(
      `SELECT p.*, 
              mr.diagnosis, mr.visit_date,
              s.first_name as doctor_first_name, s.last_name as doctor_last_name,
              s.specialization
       FROM prescriptions p
       JOIN medical_records mr ON p.record_id = mr.record_id
       JOIN staff s ON mr.doctor_id = s.staff_id
       WHERE mr.patient_id = $1 AND p.is_active = true
       ORDER BY p.prescribed_date DESC`,
      [patient_id]
    );

    res.json(formatResponse(true, result.rows, 'Patient prescriptions retrieved successfully'));

  } catch (error) {
    console.error('Get patient prescriptions error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const getActivePrescriptions = async (req, res) => {
  try {
    const { patient_id } = req.params;

    const result = await db.query(
      `SELECT p.*, 
              mr.diagnosis,
              s.first_name as doctor_first_name, s.last_name as doctor_last_name
       FROM prescriptions p
       JOIN medical_records mr ON p.record_id = mr.record_id
       JOIN staff s ON mr.doctor_id = s.staff_id
       WHERE mr.patient_id = $1 AND p.is_active = true
       AND (p.duration ~ '^[0-9]+' AND 
            p.prescribed_date + (SUBSTRING(p.duration FROM '^[0-9]+') || ' days')::INTERVAL >= CURRENT_DATE)
       ORDER BY p.prescribed_date DESC`,
      [patient_id]
    );

    res.json(formatResponse(true, result.rows, 'Active prescriptions retrieved successfully'));

  } catch (error) {
    console.error('Get active prescriptions error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

module.exports = {
  getPrescriptions,
  getPrescriptionById,
  createPrescription,
  updatePrescription,
  getPatientPrescriptions,
  getActivePrescriptions
};
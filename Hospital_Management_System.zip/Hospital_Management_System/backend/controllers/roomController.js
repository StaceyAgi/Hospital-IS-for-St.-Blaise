const db = require('../config/database');
const { formatResponse } = require('../utils/helpers');

const getAllRooms = async (req, res) => {
  try {
    const { department_id, room_type, is_available } = req.query;

    let query = `
      SELECT r.*, d.department_name
      FROM rooms r
      LEFT JOIN departments d ON r.department_id = d.department_id
      WHERE 1=1
    `;
    const params = [];
    let paramCount = 0;

    if (department_id) {
      paramCount++;
      query += ` AND r.department_id = $${paramCount}`;
      params.push(department_id);
    }

    if (room_type) {
      paramCount++;
      query += ` AND r.room_type = $${paramCount}`;
      params.push(room_type);
    }

    if (is_available !== undefined) {
      paramCount++;
      query += ` AND r.is_available = $${paramCount}`;
      params.push(is_available === 'true');
    }

    query += ` ORDER BY r.room_number`;

    const result = await db.query(query, params);

    res.json(formatResponse(true, result.rows, 'Rooms retrieved successfully'));

  } catch (error) {
    console.error('Get rooms error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const getRoomById = async (req, res) => {
  try {
    const { id } = req.params;

    const result = await db.query(
      `SELECT r.*, d.department_name
       FROM rooms r
       LEFT JOIN departments d ON r.department_id = d.department_id
       WHERE r.room_id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json(
        formatResponse(false, null, 'Room not found')
      );
    }

    res.json(formatResponse(true, result.rows[0], 'Room retrieved successfully'));

  } catch (error) {
    console.error('Get room error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const createRoom = async (req, res) => {
  try {
    const {
      room_number, room_type, department_id, capacity, price_per_day
    } = req.body;

    const result = await db.query(
      `INSERT INTO rooms (room_number, room_type, department_id, capacity, price_per_day)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [room_number, room_type, department_id, capacity, price_per_day]
    );

    res.status(201).json(
      formatResponse(true, result.rows[0], 'Room created successfully')
    );

  } catch (error) {
    if (error.code === '23505') {
      return res.status(400).json(
        formatResponse(false, null, 'Room number already exists')
      );
    }
    
    console.error('Create room error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const updateRoom = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      room_number, room_type, department_id, capacity,
      current_occupancy, is_available, price_per_day
    } = req.body;

    const result = await db.query(
      `UPDATE rooms 
       SET room_number = $1, room_type = $2, department_id = $3,
           capacity = $4, current_occupancy = $5, is_available = $6,
           price_per_day = $7
       WHERE room_id = $8
       RETURNING *`,
      [room_number, room_type, department_id, capacity, current_occupancy, is_available, price_per_day, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json(
        formatResponse(false, null, 'Room not found')
      );
    }

    res.json(formatResponse(true, result.rows[0], 'Room updated successfully'));

  } catch (error) {
    console.error('Update room error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const getAvailableRooms = async (req, res) => {
  try {
    const result = await db.query(
      `SELECT r.*, d.department_name
       FROM rooms r
       LEFT JOIN departments d ON r.department_id = d.department_id
       WHERE r.is_available = true AND r.current_occupancy < r.capacity
       ORDER BY r.room_type, r.room_number`
    );

    res.json(formatResponse(true, result.rows, 'Available rooms retrieved successfully'));

  } catch (error) {
    console.error('Get available rooms error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const getRoomStats = async (req, res) => {
  try {
    const statsQuery = `
      SELECT 
        COUNT(*) as total_rooms,
        COUNT(CASE WHEN is_available = true THEN 1 END) as available_rooms,
        COUNT(CASE WHEN is_available = false THEN 1 END) as occupied_rooms,
        COUNT(CASE WHEN room_type = 'general' THEN 1 END) as general_rooms,
        COUNT(CASE WHEN room_type = 'private' THEN 1 END) as private_rooms,
        COUNT(CASE WHEN room_type = 'icu' THEN 1 END) as icu_rooms,
        SUM(capacity) as total_capacity,
        SUM(current_occupancy) as total_occupancy
      FROM rooms
    `;

    const result = await db.query(statsQuery);
    
    res.json(formatResponse(true, result.rows[0], 'Room stats retrieved successfully'));

  } catch (error) {
    console.error('Get room stats error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

module.exports = {
  getAllRooms,
  getRoomById,
  createRoom,
  updateRoom,
  getAvailableRooms,
  getRoomStats
};
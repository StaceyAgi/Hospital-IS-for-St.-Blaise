const db = require('../config/database');
const { formatResponse } = require('../utils/helpers');

const getAllDepartments = async (req, res) => {
  try {
    const result = await db.query(
      `SELECT d.*, 
              s.first_name as head_doctor_first_name, 
              s.last_name as head_doctor_last_name
       FROM departments d
       LEFT JOIN staff s ON d.head_doctor_id = s.staff_id
       WHERE d.is_active = true
       ORDER BY d.department_name`
    );

    res.json(formatResponse(true, result.rows, 'Departments retrieved successfully'));

  } catch (error) {
    console.error('Get departments error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const getDepartmentById = async (req, res) => {
  try {
    const { id } = req.params;

    const result = await db.query(
      `SELECT d.*, 
              s.first_name as head_doctor_first_name, 
              s.last_name as head_doctor_last_name
       FROM departments d
       LEFT JOIN staff s ON d.head_doctor_id = s.staff_id
       WHERE d.department_id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json(
        formatResponse(false, null, 'Department not found')
      );
    }

    res.json(formatResponse(true, result.rows[0], 'Department retrieved successfully'));

  } catch (error) {
    console.error('Get department error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const createDepartment = async (req, res) => {
  try {
    const { department_name, description, head_doctor_id } = req.body;

    const result = await db.query(
      `INSERT INTO departments (department_name, description, head_doctor_id)
       VALUES ($1, $2, $3)
       RETURNING *`,
      [department_name, description, head_doctor_id]
    );

    res.status(201).json(
      formatResponse(true, result.rows[0], 'Department created successfully')
    );

  } catch (error) {
    console.error('Create department error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const updateDepartment = async (req, res) => {
  try {
    const { id } = req.params;
    const { department_name, description, head_doctor_id, is_active } = req.body;

    const result = await db.query(
      `UPDATE departments 
       SET department_name = $1, description = $2, 
           head_doctor_id = $3, is_active = $4
       WHERE department_id = $5
       RETURNING *`,
      [department_name, description, head_doctor_id, is_active, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json(
        formatResponse(false, null, 'Department not found')
      );
    }

    res.json(formatResponse(true, result.rows[0], 'Department updated successfully'));

  } catch (error) {
    console.error('Update department error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const getDepartmentStats = async (req, res) => {
  try {
    const statsQuery = `
      SELECT 
        d.department_name,
        COUNT(DISTINCT s.staff_id) as staff_count,
        COUNT(DISTINCT r.room_id) as room_count,
        COUNT(DISTINCT a.appointment_id) as appointment_count
      FROM departments d
      LEFT JOIN staff s ON d.department_id::text = s.department
      LEFT JOIN rooms r ON d.department_id = r.department_id
      LEFT JOIN appointments a ON s.staff_id = a.doctor_id
      WHERE d.is_active = true
      GROUP BY d.department_id, d.department_name
    `;

    const result = await db.query(statsQuery);
    
    res.json(formatResponse(true, result.rows, 'Department stats retrieved successfully'));

  } catch (error) {
    console.error('Get department stats error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

module.exports = {
  getAllDepartments,
  getDepartmentById,
  createDepartment,
  updateDepartment,
  getDepartmentStats
};
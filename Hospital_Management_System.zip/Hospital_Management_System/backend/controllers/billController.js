const db = require('../config/database');
const { formatResponse } = require('../utils/helpers');

const getAllBills = async (req, res) => {
  try {
    const { status, page = 1, limit = 10 } = req.query;
    const offset = (page - 1) * limit;

    let query = `
      SELECT b.*, 
             p.first_name as patient_first_name, p.last_name as patient_last_name,
             p.phone_number as patient_phone
      FROM bills b
      JOIN patients p ON b.patient_id = p.patient_id
      WHERE 1=1
    `;
    let countQuery = `
      SELECT COUNT(*) 
      FROM bills b
      WHERE 1=1
    `;
    const params = [];
    let paramCount = 0;

    if (status) {
      paramCount++;
      query += ` AND b.status = $${paramCount}`;
      countQuery += ` AND b.status = $${paramCount}`;
      params.push(status);
    }

    paramCount++;
    query += ` ORDER BY b.bill_date DESC LIMIT $${paramCount} OFFSET $${paramCount + 1}`;
    params.push(limit, offset);

    const [billsResult, countResult] = await Promise.all([
      db.query(query, params),
      db.query(countQuery, params.slice(0, -2))
    ]);

    const totalBills = parseInt(countResult.rows[0].count);
    const totalPages = Math.ceil(totalBills / limit);

    res.json(formatResponse(true, {
      bills: billsResult.rows,
      pagination: {
        currentPage: parseInt(page),
        totalPages,
        totalBills,
        hasNext: page < totalPages,
        hasPrev: page > 1
      }
    }, 'Bills retrieved successfully'));

  } catch (error) {
    console.error('Get bills error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const getBillById = async (req, res) => {
  try {
    const { id } = req.params;

    const result = await db.query(
      `SELECT b.*, 
              p.first_name as patient_first_name, p.last_name as patient_last_name,
              p.phone_number as patient_phone, p.email as patient_email,
              p.address as patient_address,
              a.admission_date, a.discharge_date
       FROM bills b
       JOIN patients p ON b.patient_id = p.patient_id
       LEFT JOIN admissions a ON b.admission_id = a.admission_id
       WHERE b.bill_id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json(
        formatResponse(false, null, 'Bill not found')
      );
    }

    res.json(formatResponse(true, result.rows[0], 'Bill retrieved successfully'));

  } catch (error) {
    console.error('Get bill error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const createBill = async (req, res) => {
  try {
    const {
      patient_id, admission_id, total_amount, items
    } = req.body;

    const result = await db.query(
      `INSERT INTO bills (patient_id, admission_id, total_amount, items)
       VALUES ($1, $2, $3, $4)
       RETURNING *`,
      [patient_id, admission_id, total_amount, items]
    );

    res.status(201).json(
      formatResponse(true, result.rows[0], 'Bill created successfully')
    );

  } catch (error) {
    console.error('Create bill error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const updateBill = async (req, res) => {
  try {
    const { id } = req.params;
    const { paid_amount, status, payment_method } = req.body;

    let paymentDate = null;
    if (status === 'paid' && paid_amount > 0) {
      paymentDate = new Date();
    }

    const result = await db.query(
      `UPDATE bills 
       SET paid_amount = $1, status = $2, payment_method = $3, payment_date = $4
       WHERE bill_id = $5
       RETURNING *`,
      [paid_amount, status, payment_method, paymentDate, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json(
        formatResponse(false, null, 'Bill not found')
      );
    }

    res.json(formatResponse(true, result.rows[0], 'Bill updated successfully'));

  } catch (error) {
    console.error('Update bill error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const getPatientBills = async (req, res) => {
  try {
    const { patient_id } = req.params;

    const result = await db.query(
      `SELECT b.*, a.admission_date, a.discharge_date
       FROM bills b
       LEFT JOIN admissions a ON b.admission_id = a.admission_id
       WHERE b.patient_id = $1
       ORDER BY b.bill_date DESC`,
      [patient_id]
    );

    res.json(formatResponse(true, result.rows, 'Patient bills retrieved successfully'));

  } catch (error) {
    console.error('Get patient bills error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const getBillStats = async (req, res) => {
  try {
    const statsQuery = `
      SELECT 
        COUNT(*) as total_bills,
        COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_bills,
        COUNT(CASE WHEN status = 'paid' THEN 1 END) as paid_bills,
        COUNT(CASE WHEN status = 'partial' THEN 1 END) as partial_bills,
        SUM(total_amount) as total_amount,
        SUM(paid_amount) as total_paid,
        SUM(total_amount - paid_amount) as total_due
      FROM bills
    `;

    const result = await db.query(statsQuery);
    
    res.json(formatResponse(true, result.rows[0], 'Bill stats retrieved successfully'));

  } catch (error) {
    console.error('Get bill stats error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

module.exports = {
  getAllBills,
  getBillById,
  createBill,
  updateBill,
  getPatientBills,
  getBillStats
};
const db = require('../config/database');
const { formatResponse } = require('../utils/helpers');

const getAllInventory = async (req, res) => {
  try {
    const { category, low_stock, page = 1, limit = 10 } = req.query;
    const offset = (page - 1) * limit;

    let query = `
      SELECT * FROM inventory
      WHERE is_active = true
    `;
    let countQuery = `
      SELECT COUNT(*) FROM inventory WHERE is_active = true
    `;
    const params = [];
    let paramCount = 0;

    if (category) {
      paramCount++;
      query += ` AND category = $${paramCount}`;
      countQuery += ` AND category = $${paramCount}`;
      params.push(category);
    }

    if (low_stock === 'true') {
      paramCount++;
      query += ` AND quantity <= min_quantity`;
      countQuery += ` AND quantity <= min_quantity`;
    }

    paramCount++;
    query += ` ORDER BY item_name LIMIT $${paramCount} OFFSET $${paramCount + 1}`;
    params.push(limit, offset);

    const [inventoryResult, countResult] = await Promise.all([
      db.query(query, params),
      db.query(countQuery, params.slice(0, -2))
    ]);

    const totalItems = parseInt(countResult.rows[0].count);
    const totalPages = Math.ceil(totalItems / limit);

    res.json(formatResponse(true, {
      inventory: inventoryResult.rows,
      pagination: {
        currentPage: parseInt(page),
        totalPages,
        totalItems,
        hasNext: page < totalPages,
        hasPrev: page > 1
      }
    }, 'Inventory retrieved successfully'));

  } catch (error) {
    console.error('Get inventory error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const getInventoryItemById = async (req, res) => {
  try {
    const { id } = req.params;

    const result = await db.query(
      'SELECT * FROM inventory WHERE item_id = $1',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json(
        formatResponse(false, null, 'Inventory item not found')
      );
    }

    res.json(formatResponse(true, result.rows[0], 'Inventory item retrieved successfully'));

  } catch (error) {
    console.error('Get inventory item error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const createInventoryItem = async (req, res) => {
  try {
    const {
      item_name, category, quantity, min_quantity,
      unit_price, supplier, expiry_date, storage_location
    } = req.body;

    const result = await db.query(
      `INSERT INTO inventory (
        item_name, category, quantity, min_quantity,
        unit_price, supplier, expiry_date, storage_location
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING *`,
      [item_name, category, quantity, min_quantity, unit_price, supplier, expiry_date, storage_location]
    );

    res.status(201).json(
      formatResponse(true, result.rows[0], 'Inventory item created successfully')
    );

  } catch (error) {
    console.error('Create inventory item error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const updateInventoryItem = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      item_name, category, quantity, min_quantity,
      unit_price, supplier, expiry_date, storage_location, is_active
    } = req.body;

    const result = await db.query(
      `UPDATE inventory 
       SET item_name = $1, category = $2, quantity = $3, min_quantity = $4,
           unit_price = $5, supplier = $6, expiry_date = $7, storage_location = $8,
           is_active = $9, updated_at = CURRENT_TIMESTAMP
       WHERE item_id = $10
       RETURNING *`,
      [item_name, category, quantity, min_quantity, unit_price, supplier, expiry_date, storage_location, is_active, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json(
        formatResponse(false, null, 'Inventory item not found')
      );
    }

    res.json(formatResponse(true, result.rows[0], 'Inventory item updated successfully'));

  } catch (error) {
    console.error('Update inventory item error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const updateInventoryQuantity = async (req, res) => {
  try {
    const { id } = req.params;
    const { quantity, action } = req.body; // action: 'add' or 'subtract'

    let updateQuery;
    if (action === 'add') {
      updateQuery = 'UPDATE inventory SET quantity = quantity + $1 WHERE item_id = $2 RETURNING *';
    } else if (action === 'subtract') {
      updateQuery = 'UPDATE inventory SET quantity = quantity - $1 WHERE item_id = $2 AND quantity >= $1 RETURNING *';
    } else {
      return res.status(400).json(
        formatResponse(false, null, 'Invalid action. Use "add" or "subtract"')
      );
    }

    const result = await db.query(updateQuery, [quantity, id]);

    if (result.rows.length === 0) {
      return res.status(400).json(
        formatResponse(false, null, 'Insufficient quantity or item not found')
      );
    }

    res.json(formatResponse(true, result.rows[0], 'Inventory quantity updated successfully'));

  } catch (error) {
    console.error('Update inventory quantity error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const getLowStockItems = async (req, res) => {
  try {
    const result = await db.query(
      `SELECT * FROM inventory 
       WHERE quantity <= min_quantity AND is_active = true
       ORDER BY quantity ASC`
    );

    res.json(formatResponse(true, result.rows, 'Low stock items retrieved successfully'));

  } catch (error) {
    console.error('Get low stock items error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const getInventoryStats = async (req, res) => {
  try {
    const statsQuery = `
      SELECT 
        COUNT(*) as total_items,
        COUNT(CASE WHEN quantity <= min_quantity THEN 1 END) as low_stock_items,
        COUNT(CASE WHEN expiry_date < CURRENT_DATE + INTERVAL '30 days' THEN 1 END) as expiring_soon,
        SUM(quantity * unit_price) as total_value
      FROM inventory
      WHERE is_active = true
    `;

    const result = await db.query(statsQuery);
    
    res.json(formatResponse(true, result.rows[0], 'Inventory stats retrieved successfully'));

  } catch (error) {
    console.error('Get inventory stats error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

module.exports = {
  getAllInventory,
  getInventoryItemById,
  createInventoryItem,
  updateInventoryItem,
  updateInventoryQuantity,
  getLowStockItems,
  getInventoryStats
};
const db = require('../config/database');
const { hashPassword, formatResponse } = require('../utils/helpers');

const getAllStaff = async (req, res) => {
  try {
    const { page = 1, limit = 10, role, department } = req.query;
    const offset = (page - 1) * limit;

    let query = `
      SELECT s.*, u.email, u.role, u.is_active
      FROM staff s
      JOIN users u ON s.user_id = u.user_id
      WHERE 1=1
    `;
    let countQuery = `
      SELECT COUNT(*) 
      FROM staff s
      JOIN users u ON s.user_id = u.user_id
      WHERE 1=1
    `;
    const params = [];
    let paramCount = 0;

    if (role) {
      paramCount++;
      query += ` AND u.role = $${paramCount}`;
      countQuery += ` AND u.role = $${paramCount}`;
      params.push(role);
    }

    if (department) {
      paramCount++;
      query += ` AND s.department = $${paramCount}`;
      countQuery += ` AND s.department = $${paramCount}`;
      params.push(department);
    }

    paramCount++;
    query += ` ORDER BY s.first_name, s.last_name LIMIT $${paramCount} OFFSET $${paramCount + 1}`;
    params.push(limit, offset);

    const [staffResult, countResult] = await Promise.all([
      db.query(query, params),
      db.query(countQuery, params.slice(0, -2))
    ]);

    const totalStaff = parseInt(countResult.rows[0].count);
    const totalPages = Math.ceil(totalStaff / limit);

    res.json(formatResponse(true, {
      staff: staffResult.rows,
      pagination: {
        currentPage: parseInt(page),
        totalPages,
        totalStaff,
        hasNext: page < totalPages,
        hasPrev: page > 1
      }
    }, 'Staff retrieved successfully'));

  } catch (error) {
    console.error('Get staff error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const getStaffById = async (req, res) => {
  try {
    const { id } = req.params;

    const result = await db.query(
      `SELECT s.*, u.email, u.role, u.is_active
       FROM staff s
       JOIN users u ON s.user_id = u.user_id
       WHERE s.staff_id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json(
        formatResponse(false, null, 'Staff member not found')
      );
    }

    res.json(formatResponse(true, result.rows[0], 'Staff member retrieved successfully'));

  } catch (error) {
    console.error('Get staff error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const createStaff = async (req, res) => {
  const client = await db.pool.connect();
  
  try {
    await client.query('BEGIN');

    const {
      first_name, last_name, date_of_birth, gender,
      phone_number, address, specialization, qualification,
      experience_years, department, salary, email, role
    } = req.body;

    // Default password
    const defaultPassword = 'staff123';
    const hashedPassword = await hashPassword(defaultPassword);

    // Create user first
    const userResult = await client.query(
      `INSERT INTO users (email, password_hash, role) 
       VALUES ($1, $2, $3) 
       RETURNING user_id`,
      [email, hashedPassword, role]
    );

    const userId = userResult.rows[0].user_id;

    // Create staff
    const staffResult = await client.query(
      `INSERT INTO staff (
        user_id, first_name, last_name, date_of_birth, gender,
        phone_number, address, specialization, qualification,
        experience_years, department, salary
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
      RETURNING *`,
      [
        userId, first_name, last_name, date_of_birth, gender,
        phone_number, address, specialization, qualification,
        experience_years, department, salary
      ]
    );

    await client.query('COMMIT');

    res.status(201).json(
      formatResponse(true, staffResult.rows[0], 'Staff member created successfully')
    );

  } catch (error) {
    await client.query('ROLLBACK');
    
    if (error.code === '23505') {
      return res.status(400).json(
        formatResponse(false, null, 'Email already exists')
      );
    }
    
    console.error('Create staff error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  } finally {
    client.release();
  }
};

const updateStaff = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      first_name, last_name, date_of_birth, gender,
      phone_number, address, specialization, qualification,
      experience_years, department, salary, is_active
    } = req.body;

    const result = await db.query(
      `UPDATE staff 
       SET first_name = $1, last_name = $2, date_of_birth = $3, gender = $4,
           phone_number = $5, address = $6, specialization = $7, qualification = $8,
           experience_years = $9, department = $10, salary = $11, is_active = $12,
           updated_at = CURRENT_TIMESTAMP
       WHERE staff_id = $13
       RETURNING *`,
      [
        first_name, last_name, date_of_birth, gender,
        phone_number, address, specialization, qualification,
        experience_years, department, salary, is_active, id
      ]
    );

    if (result.rows.length === 0) {
      return res.status(404).json(
        formatResponse(false, null, 'Staff member not found')
      );
    }

    res.json(formatResponse(true, result.rows[0], 'Staff member updated successfully'));

  } catch (error) {
    console.error('Update staff error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const getDoctors = async (req, res) => {
  try {
    const result = await db.query(
      `SELECT s.staff_id, s.first_name, s.last_name, s.specialization, s.department
       FROM staff s
       JOIN users u ON s.user_id = u.user_id
       WHERE u.role = 'doctor' AND s.is_active = true
       ORDER BY s.first_name, s.last_name`
    );

    res.json(formatResponse(true, result.rows, 'Doctors retrieved successfully'));

  } catch (error) {
    console.error('Get doctors error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const getStaffStats = async (req, res) => {
  try {
    const statsQuery = `
      SELECT 
        COUNT(*) as total_staff,
        COUNT(CASE WHEN u.role = 'doctor' THEN 1 END) as doctors,
        COUNT(CASE WHEN u.role = 'nurse' THEN 1 END) as nurses,
        COUNT(CASE WHEN u.role = 'receptionist' THEN 1 END) as receptionists,
        COUNT(CASE WHEN s.is_active = true THEN 1 END) as active_staff
      FROM staff s
      JOIN users u ON s.user_id = u.user_id
    `;

    const result = await db.query(statsQuery);
    
    res.json(formatResponse(true, result.rows[0], 'Staff stats retrieved successfully'));

  } catch (error) {
    console.error('Get staff stats error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

module.exports = {
  getAllStaff,
  getStaffById,
  createStaff,
  updateStaff,
  getDoctors,
  getStaffStats
};
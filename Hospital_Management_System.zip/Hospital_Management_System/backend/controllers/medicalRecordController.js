const db = require('../config/database');
const { formatResponse } = require('../utils/helpers');

const getMedicalRecords = async (req, res) => {
  try {
    const { patient_id, doctor_id, page = 1, limit = 10 } = req.query;
    const offset = (page - 1) * limit;

    let query = `
      SELECT mr.*, 
             p.first_name as patient_first_name, p.last_name as patient_last_name,
             s.first_name as doctor_first_name, s.last_name as doctor_last_name,
             s.specialization
      FROM medical_records mr
      JOIN patients p ON mr.patient_id = p.patient_id
      JOIN staff s ON mr.doctor_id = s.staff_id
      WHERE 1=1
    `;
    let countQuery = `
      SELECT COUNT(*) 
      FROM medical_records mr
      WHERE 1=1
    `;
    const params = [];
    let paramCount = 0;

    if (patient_id) {
      paramCount++;
      query += ` AND mr.patient_id = $${paramCount}`;
      countQuery += ` AND mr.patient_id = $${paramCount}`;
      params.push(patient_id);
    }

    if (doctor_id) {
      paramCount++;
      query += ` AND mr.doctor_id = $${paramCount}`;
      countQuery += ` AND mr.doctor_id = $${paramCount}`;
      params.push(doctor_id);
    }

    paramCount++;
    query += ` ORDER BY mr.visit_date DESC, mr.created_at DESC 
               LIMIT $${paramCount} OFFSET $${paramCount + 1}`;
    params.push(limit, offset);

    const [recordsResult, countResult] = await Promise.all([
      db.query(query, params),
      db.query(countQuery, params.slice(0, -2))
    ]);

    const totalRecords = parseInt(countResult.rows[0].count);
    const totalPages = Math.ceil(totalRecords / limit);

    res.json(formatResponse(true, {
      medicalRecords: recordsResult.rows,
      pagination: {
        currentPage: parseInt(page),
        totalPages,
        totalRecords,
        hasNext: page < totalPages,
        hasPrev: page > 1
      }
    }, 'Medical records retrieved successfully'));

  } catch (error) {
    console.error('Get medical records error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const getMedicalRecordById = async (req, res) => {
  try {
    const { id } = req.params;

    const result = await db.query(
      `SELECT mr.*, 
              p.first_name as patient_first_name, p.last_name as patient_last_name,
              p.date_of_birth as patient_dob, p.gender as patient_gender,
              p.blood_type, p.allergies,
              s.first_name as doctor_first_name, s.last_name as doctor_last_name,
              s.specialization, s.department
       FROM medical_records mr
       JOIN patients p ON mr.patient_id = p.patient_id
       JOIN staff s ON mr.doctor_id = s.staff_id
       WHERE mr.record_id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json(
        formatResponse(false, null, 'Medical record not found')
      );
    }

    res.json(formatResponse(true, result.rows[0], 'Medical record retrieved successfully'));

  } catch (error) {
    console.error('Get medical record error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const createMedicalRecord = async (req, res) => {
  try {
    const {
      patient_id, doctor_id, visit_date, diagnosis, symptoms,
      treatment, prescription, vital_signs, notes, follow_up_date
    } = req.body;

    const result = await db.query(
      `INSERT INTO medical_records (
        patient_id, doctor_id, visit_date, diagnosis, symptoms,
        treatment, prescription, vital_signs, notes, follow_up_date
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
      RETURNING *`,
      [
        patient_id, doctor_id, visit_date, diagnosis, symptoms,
        treatment, prescription, vital_signs, notes, follow_up_date
      ]
    );

    res.status(201).json(
      formatResponse(true, result.rows[0], 'Medical record created successfully')
    );

  } catch (error) {
    console.error('Create medical record error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const updateMedicalRecord = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      diagnosis, symptoms, treatment, prescription,
      vital_signs, notes, follow_up_date
    } = req.body;

    const result = await db.query(
      `UPDATE medical_records 
       SET diagnosis = $1, symptoms = $2, treatment = $3,
           prescription = $4, vital_signs = $5, notes = $6,
           follow_up_date = $7
       WHERE record_id = $8
       RETURNING *`,
      [diagnosis, symptoms, treatment, prescription, vital_signs, notes, follow_up_date, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json(
        formatResponse(false, null, 'Medical record not found')
      );
    }

    res.json(formatResponse(true, result.rows[0], 'Medical record updated successfully'));

  } catch (error) {
    console.error('Update medical record error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const getPatientMedicalHistory = async (req, res) => {
  try {
    const { patient_id } = req.params;

    const result = await db.query(
      `SELECT mr.*, 
              s.first_name as doctor_first_name, s.last_name as doctor_last_name,
              s.specialization
       FROM medical_records mr
       JOIN staff s ON mr.doctor_id = s.staff_id
       WHERE mr.patient_id = $1
       ORDER BY mr.visit_date DESC, mr.created_at DESC`,
      [patient_id]
    );

    res.json(formatResponse(true, result.rows, 'Patient medical history retrieved successfully'));

  } catch (error) {
    console.error('Get patient medical history error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

module.exports = {
  getMedicalRecords,
  getMedicalRecordById,
  createMedicalRecord,
  updateMedicalRecord,
  getPatientMedicalHistory
};
const db = require('../config/database');
const { hashPassword, formatResponse } = require('../utils/helpers');

const getAllPatients = async (req, res) => {
  try {
    const { page = 1, limit = 10, search = '' } = req.query;
    const offset = (page - 1) * limit;

    let query = `
      SELECT p.*, u.email, u.is_active
      FROM patients p
      JOIN users u ON p.user_id = u.user_id
      WHERE 1=1
    `;
    let countQuery = `
      SELECT COUNT(*) 
      FROM patients p
      JOIN users u ON p.user_id = u.user_id
      WHERE 1=1
    `;
    const params = [];
    let paramCount = 0;

    if (search) {
      paramCount++;
      query += ` AND (p.first_name ILIKE $${paramCount} OR p.last_name ILIKE $${paramCount} OR p.phone_number ILIKE $${paramCount})`;
      countQuery += ` AND (p.first_name ILIKE $${paramCount} OR p.last_name ILIKE $${paramCount} OR p.phone_number ILIKE $${paramCount})`;
      params.push(`%${search}%`);
    }

    paramCount++;
    query += ` ORDER BY p.created_at DESC LIMIT $${paramCount} OFFSET $${paramCount + 1}`;
    params.push(limit, offset);

    const [patientsResult, countResult] = await Promise.all([
      db.query(query, params),
      db.query(countQuery, params.slice(0, -2))
    ]);

    const totalPatients = parseInt(countResult.rows[0].count);
    const totalPages = Math.ceil(totalPatients / limit);

    res.json(formatResponse(true, {
      patients: patientsResult.rows,
      pagination: {
        currentPage: parseInt(page),
        totalPages,
        totalPatients,
        hasNext: page < totalPages,
        hasPrev: page > 1
      }
    }, 'Patients retrieved successfully'));

  } catch (error) {
    console.error('Get patients error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const getPatientById = async (req, res) => {
  try {
    const { id } = req.params;

    const result = await db.query(
      `SELECT p.*, u.email, u.is_active
       FROM patients p
       JOIN users u ON p.user_id = u.user_id
       WHERE p.patient_id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json(
        formatResponse(false, null, 'Patient not found')
      );
    }

    res.json(formatResponse(true, result.rows[0], 'Patient retrieved successfully'));

  } catch (error) {
    console.error('Get patient error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const createPatient = async (req, res) => {
  const client = await db.pool.connect();
  
  try {
    await client.query('BEGIN');

    const {
      first_name, last_name, date_of_birth, gender,
      phone_number, email, address, emergency_contact_name,
      emergency_contact_phone, blood_type, allergies, medical_history
    } = req.body;

    // Default password (should be changed by patient later)
    const defaultPassword = 'patient123';
    const hashedPassword = await hashPassword(defaultPassword);

    // Create user first
    const userResult = await client.query(
      `INSERT INTO users (email, password_hash, role) 
       VALUES ($1, $2, 'patient') 
       RETURNING user_id`,
      [email, hashedPassword]
    );

    const userId = userResult.rows[0].user_id;

    // Create patient
    const patientResult = await client.query(
      `INSERT INTO patients (
        user_id, first_name, last_name, date_of_birth, gender,
        phone_number, email, address, emergency_contact_name,
        emergency_contact_phone, blood_type, allergies, medical_history
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
      RETURNING *`,
      [
        userId, first_name, last_name, date_of_birth, gender,
        phone_number, email, address, emergency_contact_name,
        emergency_contact_phone, blood_type, allergies, medical_history
      ]
    );

    await client.query('COMMIT');

    res.status(201).json(
      formatResponse(true, patientResult.rows[0], 'Patient created successfully')
    );

  } catch (error) {
    await client.query('ROLLBACK');
    
    if (error.code === '23505') { // Unique violation
      return res.status(400).json(
        formatResponse(false, null, 'Email already exists')
      );
    }
    
    console.error('Create patient error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  } finally {
    client.release();
  }
};

const updatePatient = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      first_name, last_name, date_of_birth, gender,
      phone_number, address, emergency_contact_name,
      emergency_contact_phone, blood_type, allergies, medical_history
    } = req.body;

    const result = await db.query(
      `UPDATE patients 
       SET first_name = $1, last_name = $2, date_of_birth = $3, gender = $4,
           phone_number = $5, address = $6, emergency_contact_name = $7,
           emergency_contact_phone = $8, blood_type = $9, allergies = $10,
           medical_history = $11, updated_at = CURRENT_TIMESTAMP
       WHERE patient_id = $12
       RETURNING *`,
      [
        first_name, last_name, date_of_birth, gender,
        phone_number, address, emergency_contact_name,
        emergency_contact_phone, blood_type, allergies, medical_history, id
      ]
    );

    if (result.rows.length === 0) {
      return res.status(404).json(
        formatResponse(false, null, 'Patient not found')
      );
    }

    res.json(formatResponse(true, result.rows[0], 'Patient updated successfully'));

  } catch (error) {
    console.error('Update patient error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

const getPatientStats = async (req, res) => {
  try {
    const statsQuery = `
      SELECT 
        COUNT(*) as total_patients,
        COUNT(CASE WHEN gender = 'Male' THEN 1 END) as male_patients,
        COUNT(CASE WHEN gender = 'Female' THEN 1 END) as female_patients,
        COUNT(CASE WHEN date_of_birth > CURRENT_DATE - INTERVAL '18 years' THEN 1 END) as pediatric_patients,
        COUNT(CASE WHEN date_of_birth <= CURRENT_DATE - INTERVAL '65 years' THEN 1 END) as senior_patients
      FROM patients
    `;

    const result = await db.query(statsQuery);
    
    res.json(formatResponse(true, result.rows[0], 'Patient stats retrieved successfully'));

  } catch (error) {
    console.error('Get patient stats error:', error);
    res.status(500).json(
      formatResponse(false, null, 'Server error', error.message)
    );
  }
};

module.exports = {
  getAllPatients,
  getPatientById,
  createPatient,
  updatePatient,
  getPatientStats
};
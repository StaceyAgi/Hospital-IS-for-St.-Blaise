const express = require('express');
const router = express.Router();
const { 
  getAllRooms, 
  getRoomById, 
  createRoom, 
  updateRoom, 
  getAvailableRooms,
  getRoomStats 
} = require('../controllers/roomController');
const { authenticateToken, authorizeRoles } = require('../middleware/auth');

// All routes require authentication
router.use(authenticateToken);

// Routes accessible by admin, receptionist, nurse
router.get('/', authorizeRoles('admin', 'receptionist', 'nurse'), getAllRooms);
router.get('/available', authorizeRoles('admin', 'receptionist', 'nurse'), getAvailableRooms);
router.get('/:id', authorizeRoles('admin', 'receptionist', 'nurse'), getRoomById);

// Routes accessible by admin only
router.get('/stats/stats', authorizeRoles('admin'), getRoomStats);
router.post('/', authorizeRoles('admin'), createRoom);
router.put('/:id', authorizeRoles('admin'), updateRoom);

module.exports = router;
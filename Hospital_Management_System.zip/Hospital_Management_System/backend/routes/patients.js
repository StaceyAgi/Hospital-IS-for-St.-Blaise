const express = require('express');
const router = express.Router();
const { 
  getAllPatients, 
  getPatientById, 
  createPatient, 
  updatePatient, 
  getPatientStats 
} = require('../controllers/patientController');
const { authenticateToken, authorizeRoles } = require('../middleware/auth');
const { validatePatient } = require('../middleware/validation');

// All routes require authentication
router.use(authenticateToken);

// Routes accessible by admin, receptionist, doctor, nurse
router.get('/', authorizeRoles('admin', 'receptionist', 'doctor', 'nurse'), getAllPatients);
router.get('/stats', authorizeRoles('admin', 'receptionist', 'doctor'), getPatientStats);
router.get('/:id', authorizeRoles('admin', 'receptionist', 'doctor', 'nurse'), getPatientById);

// Routes accessible by admin and receptionist only
router.post('/', authorizeRoles('admin', 'receptionist'), validatePatient, createPatient);
router.put('/:id', authorizeRoles('admin', 'receptionist'), updatePatient);

module.exports = router;
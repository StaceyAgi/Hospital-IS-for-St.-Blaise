const express = require('express');
const router = express.Router();
const { 
  getAllDepartments, 
  getDepartmentById, 
  createDepartment, 
  updateDepartment, 
  getDepartmentStats 
} = require('../controllers/departmentController');
const { authenticateToken, authorizeRoles } = require('../middleware/auth');

// All routes require authentication
router.use(authenticateToken);

// Routes accessible by all authenticated users
router.get('/', getAllDepartments);
router.get('/:id', getDepartmentById);

// Routes accessible by admin only
router.get('/stats/stats', authorizeRoles('admin'), getDepartmentStats);
router.post('/', authorizeRoles('admin'), createDepartment);
router.put('/:id', authorizeRoles('admin'), updateDepartment);

module.exports = router;
const express = require('express');
const router = express.Router();
const { 
  getAllStaff, 
  getStaffById, 
  createStaff, 
  updateStaff, 
  getDoctors,
  getStaffStats 
} = require('../controllers/staffController');
const { authenticateToken, authorizeRoles } = require('../middleware/auth');

// All routes require authentication
router.use(authenticateToken);

// Routes accessible by admin only
router.get('/', authorizeRoles('admin'), getAllStaff);
router.get('/stats', authorizeRoles('admin'), getStaffStats);
router.get('/doctors', authorizeRoles('admin', 'receptionist', 'nurse'), getDoctors);
router.get('/:id', authorizeRoles('admin'), getStaffById);
router.post('/', authorizeRoles('admin'), createStaff);
router.put('/:id', authorizeRoles('admin'), updateStaff);

module.exports = router;
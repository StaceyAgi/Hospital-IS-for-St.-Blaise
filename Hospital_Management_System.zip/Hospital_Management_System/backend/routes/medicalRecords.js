const express = require('express');
const router = express.Router();
const { 
  getMedicalRecords, 
  getMedicalRecordById, 
  createMedicalRecord, 
  updateMedicalRecord, 
  getPatientMedicalHistory 
} = require('../controllers/medicalRecordController');
const { authenticateToken, authorizeRoles } = require('../middleware/auth');
const { validateMedicalRecord } = require('../middleware/validation');

// All routes require authentication
router.use(authenticateToken);

// Routes accessible by admin, doctor
router.get('/', authorizeRoles('admin', 'doctor'), getMedicalRecords);
router.get('/patient/:patient_id', authorizeRoles('admin', 'doctor'), getPatientMedicalHistory);
router.get('/:id', authorizeRoles('admin', 'doctor'), getMedicalRecordById);

// Routes accessible by doctor only
router.post('/', authorizeRoles('doctor'), validateMedicalRecord, createMedicalRecord);
router.put('/:id', authorizeRoles('doctor'), updateMedicalRecord);

module.exports = router;
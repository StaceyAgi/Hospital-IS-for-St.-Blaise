const express = require('express');
const router = express.Router();
const { 
  getPrescriptions, 
  getPrescriptionById, 
  createPrescription, 
  updatePrescription, 
  getPatientPrescriptions,
  getActivePrescriptions 
} = require('../controllers/prescriptionController');
const { authenticateToken, authorizeRoles } = require('../middleware/auth');

// All routes require authentication
router.use(authenticateToken);

// Routes accessible by admin, doctor, nurse
router.get('/', authorizeRoles('admin', 'doctor', 'nurse'), getPrescriptions);
router.get('/patient/:patient_id', authorizeRoles('admin', 'doctor', 'nurse'), getPatientPrescriptions);
router.get('/patient/:patient_id/active', authorizeRoles('admin', 'doctor', 'nurse'), getActivePrescriptions);
router.get('/:id', authorizeRoles('admin', 'doctor', 'nurse'), getPrescriptionById);

// Routes accessible by doctor only
router.post('/', authorizeRoles('doctor'), createPrescription);
router.put('/:id', authorizeRoles('doctor'), updatePrescription);

module.exports = router;
const express = require('express');
const router = express.Router();
const { 
  getAllInventory, 
  getInventoryItemById, 
  createInventoryItem, 
  updateInventoryItem, 
  updateInventoryQuantity,
  getLowStockItems,
  getInventoryStats 
} = require('../controllers/inventoryController');
const { authenticateToken, authorizeRoles } = require('../middleware/auth');

// All routes require authentication
router.use(authenticateToken);

// Routes accessible by admin, nurse
router.get('/', authorizeRoles('admin', 'nurse'), getAllInventory);
router.get('/low-stock', authorizeRoles('admin', 'nurse'), getLowStockItems);
router.get('/:id', authorizeRoles('admin', 'nurse'), getInventoryItemById);

// Routes accessible by admin only
router.get('/stats/stats', authorizeRoles('admin'), getInventoryStats);
router.post('/', authorizeRoles('admin'), createInventoryItem);
router.put('/:id', authorizeRoles('admin'), updateInventoryItem);
router.patch('/:id/quantity', authorizeRoles('admin'), updateInventoryQuantity);

module.exports = router;
const express = require('express');
const router = express.Router();
const { 
  getAllAppointments, 
  getAppointmentById, 
  createAppointment, 
  updateAppointment, 
  getDoctorAppointments,
  getAppointmentStats 
} = require('../controllers/appointmentController');
const { authenticateToken, authorizeRoles } = require('../middleware/auth');
const { validateAppointment } = require('../middleware/validation');

// All routes require authentication
router.use(authenticateToken);

// Routes accessible by admin, receptionist, doctor
router.get('/', authorizeRoles('admin', 'receptionist', 'doctor'), getAllAppointments);
router.get('/stats', authorizeRoles('admin', 'receptionist', 'doctor'), getAppointmentStats);
router.get('/doctor/:doctor_id', authorizeRoles('admin', 'receptionist', 'doctor'), getDoctorAppointments);
router.get('/:id', authorizeRoles('admin', 'receptionist', 'doctor'), getAppointmentById);

// Routes accessible by admin and receptionist only
router.post('/', authorizeRoles('admin', 'receptionist'), validateAppointment, createAppointment);
router.put('/:id', authorizeRoles('admin', 'receptionist'), updateAppointment);

module.exports = router;
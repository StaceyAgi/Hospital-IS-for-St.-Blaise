const express = require('express');
const router = express.Router();
const { 
  getAllAdmissions, 
  getAdmissionById, 
  createAdmission, 
  updateAdmission, 
  dischargePatient,
  getCurrentAdmissions 
} = require('../controllers/admissionController');
const { authenticateToken, authorizeRoles } = require('../middleware/auth');

// All routes require authentication
router.use(authenticateToken);

// Routes accessible by admin, receptionist, nurse, doctor
router.get('/', authorizeRoles('admin', 'receptionist', 'nurse', 'doctor'), getAllAdmissions);
router.get('/current', authorizeRoles('admin', 'receptionist', 'nurse', 'doctor'), getCurrentAdmissions);
router.get('/:id', authorizeRoles('admin', 'receptionist', 'nurse', 'doctor'), getAdmissionById);

// Routes accessible by admin and receptionist only
router.post('/', authorizeRoles('admin', 'receptionist'), createAdmission);
router.put('/:id', authorizeRoles('admin', 'receptionist'), updateAdmission);
router.put('/:id/discharge', authorizeRoles('admin', 'receptionist'), dischargePatient);

module.exports = router;
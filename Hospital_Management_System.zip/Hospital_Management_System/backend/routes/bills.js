const express = require('express');
const router = express.Router();
const { 
  getAllBills, 
  getBillById, 
  createBill, 
  updateBill, 
  getPatientBills,
  getBillStats 
} = require('../controllers/billController');
const { authenticateToken, authorizeRoles } = require('../middleware/auth');

// All routes require authentication
router.use(authenticateToken);

// Routes accessible by admin, receptionist
router.get('/', authorizeRoles('admin', 'receptionist'), getAllBills);
router.get('/stats', authorizeRoles('admin', 'receptionist'), getBillStats);
router.get('/patient/:patient_id', authorizeRoles('admin', 'receptionist'), getPatientBills);
router.get('/:id', authorizeRoles('admin', 'receptionist'), getBillById);

// Routes accessible by admin and receptionist only
router.post('/', authorizeRoles('admin', 'receptionist'), createBill);
router.put('/:id', authorizeRoles('admin', 'receptionist'), updateBill);

module.exports = router;
const express = require('express');
const router = express.Router();
const db = require('../config/database');

// Get all doctors
router.get('/', async (req, res) => {
  try {
    const result = await db.query(`
      SELECT d.*, dep.name as department_name 
      FROM doctors d 
      LEFT JOIN departments dep ON d.department = dep.name 
      ORDER BY d.created_at DESC
    `);
    res.json({ doctors: result.rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch doctors' });
  }
});

// Get available doctors
router.get('/available', async (req, res) => {
  try {
    const result = await db.query('SELECT * FROM doctors WHERE available = true ORDER BY first_name');
    res.json({ doctors: result.rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch available doctors' });
  }
});

// Get doctor by ID
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await db.query(`
      SELECT d.*, dep.name as department_name 
      FROM doctors d 
      LEFT JOIN departments dep ON d.department = dep.name 
      WHERE d.id = $1
    `, [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Doctor not found' });
    }
    
    res.json({ doctor: result.rows[0] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch doctor' });
  }
});

// Create new doctor
router.post('/', async (req, res) => {
  try {
    const {
      first_name, last_name, specialization, email, phone,
      license_number, department, experience_years, consultation_fee
    } = req.body;

    const result = await db.query(
      `INSERT INTO doctors (
        first_name, last_name, specialization, email, phone, license_number,
        department, experience_years, consultation_fee
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *`,
      [
        first_name, last_name, specialization, email, phone,
        license_number, department, experience_years, consultation_fee
      ]
    );

    res.status(201).json({ doctor: result.rows[0] });
  } catch (err) {
    console.error(err);
    if (err.code === '23505') {
      return res.status(400).json({ error: 'Email or license number already exists' });
    }
    res.status(500).json({ error: 'Failed to create doctor' });
  }
});

// Update doctor availability
router.patch('/:id/availability', async (req, res) => {
  try {
    const { id } = req.params;
    const { available } = req.body;

    const result = await db.query(
      'UPDATE doctors SET available = $1 WHERE id = $2 RETURNING *',
      [available, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Doctor not found' });
    }

    res.json({ doctor: result.rows[0] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to update doctor availability' });
  }
});

module.exports = router;

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Users Table (for authentication)
CREATE TABLE users (
    user_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL CHECK (role IN ('admin', 'doctor', 'nurse', 'receptionist', 'patient')),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Staff Table (Doctors, Nurses, Receptionists)
CREATE TABLE staff (
    staff_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(user_id) ON DELETE CASCADE,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    date_of_birth DATE NOT NULL,
    gender VARCHAR(10) CHECK (gender IN ('Male', 'Female', 'Other')),
    phone_number VARCHAR(20),
    address TEXT,
    specialization VARCHAR(100),
    qualification TEXT,
    experience_years INTEGER,
    department VARCHAR(100),
    salary DECIMAL(10,2),
    hire_date DATE DEFAULT CURRENT_DATE,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. Patients Table
CREATE TABLE patients (
    patient_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(user_id) ON DELETE CASCADE,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    date_of_birth DATE NOT NULL,
    gender VARCHAR(10) CHECK (gender IN ('Male', 'Female', 'Other')),
    phone_number VARCHAR(20),
    email VARCHAR(255),
    address TEXT,
    emergency_contact_name VARCHAR(100),
    emergency_contact_phone VARCHAR(20),
    blood_type VARCHAR(5) CHECK (blood_type IN ('A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-')),
    allergies TEXT,
    medical_history TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 4. Appointments Table
CREATE TABLE appointments (
    appointment_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    patient_id UUID REFERENCES patients(patient_id) ON DELETE CASCADE,
    doctor_id UUID REFERENCES staff(staff_id) ON DELETE CASCADE,
    appointment_date DATE NOT NULL,
    appointment_time TIME NOT NULL,
    status VARCHAR(20) DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'completed', 'cancelled', 'no_show')),
    reason TEXT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 5. Medical Records Table
CREATE TABLE medical_records (
    record_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    patient_id UUID REFERENCES patients(patient_id) ON DELETE CASCADE,
    doctor_id UUID REFERENCES staff(staff_id) ON DELETE CASCADE,
    visit_date DATE DEFAULT CURRENT_DATE,
    diagnosis TEXT,
    symptoms TEXT,
    treatment TEXT,
    prescription TEXT,
    vital_signs JSONB,
    notes TEXT,
    follow_up_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 6. Departments Table
CREATE TABLE departments (
    department_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    department_name VARCHAR(100) NOT NULL,
    description TEXT,
    head_doctor_id UUID REFERENCES staff(staff_id),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 7. Rooms/Wards Table
CREATE TABLE rooms (
    room_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    room_number VARCHAR(20) UNIQUE NOT NULL,
    room_type VARCHAR(50) CHECK (room_type IN ('general', 'private', 'icu', 'emergency', 'operation_theater')),
    department_id UUID REFERENCES departments(department_id),
    capacity INTEGER DEFAULT 1,
    current_occupancy INTEGER DEFAULT 0,
    is_available BOOLEAN DEFAULT true,
    price_per_day DECIMAL(10,2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 8. Admissions Table
CREATE TABLE admissions (
    admission_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    patient_id UUID REFERENCES patients(patient_id) ON DELETE CASCADE,
    room_id UUID REFERENCES rooms(room_id),
    admission_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    discharge_date TIMESTAMP,
    reason TEXT,
    status VARCHAR(20) DEFAULT 'admitted' CHECK (status IN ('admitted', 'discharged', 'transferred')),
    assigned_doctor_id UUID REFERENCES staff(staff_id),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 9. Billing Table
CREATE TABLE bills (
    bill_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    patient_id UUID REFERENCES patients(patient_id) ON DELETE CASCADE,
    admission_id UUID REFERENCES admissions(admission_id),
    bill_date DATE DEFAULT CURRENT_DATE,
    due_date DATE DEFAULT CURRENT_DATE + INTERVAL '30 days',
    total_amount DECIMAL(10,2) NOT NULL,
    paid_amount DECIMAL(10,2) DEFAULT 0,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'partial', 'overdue')),
    payment_method VARCHAR(50),
    payment_date TIMESTAMP,
    items JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 10. Inventory Table
CREATE TABLE inventory (
    item_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    item_name VARCHAR(255) NOT NULL,
    category VARCHAR(100) NOT NULL,
    quantity INTEGER NOT NULL,
    min_quantity INTEGER DEFAULT 10,
    unit_price DECIMAL(10,2) NOT NULL,
    supplier VARCHAR(255),
    expiry_date DATE,
    storage_location VARCHAR(100),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 11. Prescriptions Table
CREATE TABLE prescriptions (
    prescription_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    record_id UUID REFERENCES medical_records(record_id) ON DELETE CASCADE,
    medication_name VARCHAR(255) NOT NULL,
    dosage VARCHAR(100) NOT NULL,
    frequency VARCHAR(100) NOT NULL,
    duration VARCHAR(100) NOT NULL,
    instructions TEXT,
    prescribed_date DATE DEFAULT CURRENT_DATE,
    is_active BOOLEAN DEFAULT true
);

-- Create indexes for better performance
CREATE INDEX idx_appointments_patient_id ON appointments(patient_id);
CREATE INDEX idx_appointments_doctor_id ON appointments(doctor_id);
CREATE INDEX idx_appointments_date ON appointments(appointment_date);
CREATE INDEX idx_medical_records_patient_id ON medical_records(patient_id);
CREATE INDEX idx_medical_records_doctor_id ON medical_records(doctor_id);
CREATE INDEX idx_admissions_patient_id ON admissions(patient_id);
CREATE INDEX idx_admissions_room_id ON admissions(room_id);
CREATE INDEX idx_bills_patient_id ON bills(patient_id);
CREATE INDEX idx_staff_user_id ON staff(user_id);
CREATE INDEX idx_patients_user_id ON patients(user_id);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_rooms_department_id ON rooms(department_id);

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply triggers to tables that need updated_at
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_staff_updated_at BEFORE UPDATE ON staff FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_patients_updated_at BEFORE UPDATE ON patients FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_appointments_updated_at BEFORE UPDATE ON appointments FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_inventory_updated_at BEFORE UPDATE ON inventory FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Insert sample data

-- 1. Insert Users
INSERT INTO users (user_id, email, password_hash, role) VALUES
-- Admin (password: admin123)
('11111111-1111-1111-1111-111111111111', 'admin@hospital.com', '$2b$10$j27eRNcK7XIR0wHAIMDspuG5oX2MAuOFMaoKccd0NyrVVv54fFmnO ', 'admin'),
-- Doctors (password: doctor123)
('22222222-2222-2222-2222-222222222222', 'dr.smith@hospital.com', '$2b$10$zmRrtqkv0awqM.RabyzWpecc/WmvO4PLp.1hst6kxhjNrLk22tpFu', 'doctor'),
('33333333-3333-3333-3333-333333333333', 'dr.johnson@hospital.com', '$2b$10$zmRrtqkv0awqM.RabyzWpecc/WmvO4PLp.1hst6kxhjNrLk22tpFu', 'doctor'),
('44444444-4444-4444-4444-444444444444', 'dr.wilson@hospital.com', '$2b$10$zmRrtqkv0awqM.RabyzWpecc/WmvO4PLp.1hst6kxhjNrLk22tpFu', 'doctor'),
-- Nurses (password: nurse123)
('55555555-5555-5555-5555-555555555555', 'nurse.brown@hospital.com', '$2b$10$yr4yFmx6Zyj2NT4Ecue4gOXUdJC9aGf2Ph4x9pdTZZkn.KKR8RCqK', 'nurse'),
('66666666-6666-6666-6666-666666666666', 'nurse.davis@hospital.com', '$2b$10$yr4yFmx6Zyj2NT4Ecue4gOXUdJC9aGf2Ph4x9pdTZZkn.KKR8RCqK', 'nurse'),
-- Receptionist (password: reception123)
('77777777-7777-7777-7777-777777777777', 'reception@hospital.com', '$2b$10$fU8Z48ZcLB2x7mhBOKTvquJU.dWC2PmptNFAf/dkgmt736.7jVKQq ', 'receptionist'),
-- Patients (password: patient123)
('88888888-8888-8888-8888-888888888888', 'patient1@email.com', '$2b$10$jy.Efoyq5xZKdwFJrHZro.V871qhlF33I1BKPckVzYob0iaJ8ij4S', 'patient'),
('99999999-9999-9999-9999-999999999999', 'patient2@email.com', '$2b$10$jy.Efoyq5xZKdwFJrHZro.V871qhlF33I1BKPckVzYob0iaJ8ij4S', 'patient'),
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'patient3@email.com', '$2b$10$jy.Efoyq5xZKdwFJrHZro.V871qhlF33I1BKPckVzYob0iaJ8ij4S', 'patient');

-- 2. Insert Staff
INSERT INTO staff (staff_id, user_id, first_name, last_name, date_of_birth, gender, phone_number, specialization, qualification, experience_years, department, salary, hire_date) VALUES
-- Doctors
('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', '22222222-2222-2222-2222-222222222222', 'John', 'Smith', '1975-03-15', 'Male', '+1-555-0101', 'Cardiology', 'MD in Cardiology, Board Certified', 15, 'Cardiology', 150000.00, '2010-05-01'),
('cccccccc-cccc-cccc-cccc-cccccccccccc', '33333333-3333-3333-3333-333333333333', 'Sarah', 'Johnson', '1980-07-22', 'Female', '+1-555-0102', 'Pediatrics', 'MD in Pediatrics', 10, 'Pediatrics', 130000.00, '2015-08-15'),
('dddddddd-dddd-dddd-dddd-dddddddddddd', '44444444-4444-4444-4444-444444444444', 'Michael', 'Wilson', '1978-11-30', 'Male', '+1-555-0103', 'Orthopedics', 'MD in Orthopedic Surgery', 12, 'Orthopedics', 145000.00, '2013-03-20'),
-- Nurses
('eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee', '55555555-5555-5555-5555-555555555555', 'Emily', 'Brown', '1985-05-10', 'Female', '+1-555-0104', 'General Nursing', 'BSN, RN', 8, 'General', 65000.00, '2017-01-10'),
('ffffffff-ffff-ffff-ffff-ffffffffffff', '66666666-6666-6666-6666-666666666666', 'Jennifer', 'Davis', '1990-09-15', 'Female', '+1-555-0105', 'Emergency Care', 'BSN, RN, CEN', 6, 'Emergency', 68000.00, '2019-06-01'),
-- Receptionist
('gggggggg-gggg-gggg-gggg-gggggggggggg', '77777777-7777-7777-7777-777777777777', 'Robert', 'Miller', '1992-03-25', 'Male', '+1-555-0106', 'Administration', 'BBA in Healthcare Management', 4, 'Administration', 45000.00, '2020-02-15'),

-- 3. Insert Patients
INSERT INTO patients (patient_id, user_id, first_name, last_name, date_of_birth, gender, phone_number, email, address, emergency_contact_name, emergency_contact_phone, blood_type, allergies, medical_history) VALUES
('hhhhhhhh-hhhh-hhhh-hhhh-hhhhhhhhhhhh', '88888888-8888-8888-8888-888888888888', 'Alice', 'Johnson', '1988-04-12', 'Female', '+1-555-0201', 'alice.johnson@email.com', '123 Main Street, New York, NY 10001', 'Bob Johnson', '+1-555-0202', 'A+', 'Penicillin, Peanuts', 'Hypertension, Asthma'),
('iiiiiiii-iiii-iiii-iiii-iiiiiiiiiiii', '99999999-9999-9999-9999-999999999999', 'Robert', 'Davis', '1979-09-25', 'Male', '+1-555-0203', 'robert.davis@email.com', '456 Oak Avenue, Los Angeles, CA 90001', 'Mary Davis', '+1-555-0204', 'O-', 'None', 'Diabetes Type 2'),
('jjjjjjjj-jjjj-jjjj-jjjj-jjjjjjjjjjjj', 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'Maria', 'Garcia', '1995-12-05', 'Female', '+1-555-0205', 'maria.garcia@email.com', '789 Pine Road, Chicago, IL 60007', 'Carlos Garcia', '+1-555-0206', 'B+', 'Shellfish', 'Migraine');

-- 4. Insert Departments
INSERT INTO departments (department_id, department_name, description, head_doctor_id) VALUES
('kkkkkkkk-kkkk-kkkk-kkkk-kkkkkkkkkkkk', 'Cardiology', 'Specializes in heart and cardiovascular system disorders', 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb'),
('llllllll-llll-llll-llll-llllllllllll', 'Pediatrics', 'Provides medical care for infants, children, and adolescents', 'cccccccc-cccc-cccc-cccc-cccccccccccc'),
('mmmmmmmm-mmmm-mmmm-mmmm-mmmmmmmmmmmm', 'Orthopedics', 'Focuses on musculoskeletal system injuries and disorders', 'dddddddd-dddd-dddd-dddd-dddddddddddd'),
('nnnnnnnn-nnnn-nnnn-nnnn-nnnnnnnnnnnn', 'Emergency', 'Provides immediate medical care for acute illnesses and injuries', NULL),
('oooooooo-oooo-oooo-oooo-oooooooooooo', 'General Medicine', 'Comprehensive healthcare for adults', NULL);

-- 5. Insert Rooms
INSERT INTO rooms (room_id, room_number, room_type, department_id, capacity, price_per_day) VALUES
('pppppppp-pppp-pppp-pppp-pppppppppppp', '101', 'general', 'oooooooo-oooo-oooo-oooo-oooooooooooo', 2, 100.00),
('qqqqqqqq-qqqq-qqqq-qqqq-qqqqqqqqqqqq', '102', 'private', 'oooooooo-oooo-oooo-oooo-oooooooooooo', 1, 200.00),
('rrrrrrrr-rrrr-rrrr-rrrr-rrrrrrrrrrrr', '103', 'private', 'oooooooo-oooo-oooo-oooo-oooooooooooo', 1, 200.00),
('ssssssss-ssss-ssss-ssss-ssssssssssss', 'ICU-01', 'icu', 'nnnnnnnn-nnnn-nnnn-nnnn-nnnnnnnnnnnn', 1, 500.00),
('tttttttt-tttt-tttt-tttt-tttttttttttt', 'ICU-02', 'icu', 'nnnnnnnn-nnnn-nnnn-nnnn-nnnnnnnnnnnn', 1, 500.00),
('uuuuuuuu-uuuu-uuuu-uuuu-uuuuuuuuuuuu', 'ER-01', 'emergency', 'nnnnnnnn-nnnn-nnnn-nnnn-nnnnnnnnnnnn', 1, 300.00);

-- 6. Insert Appointments
INSERT INTO appointments (appointment_id, patient_id, doctor_id, appointment_date, appointment_time, status, reason) VALUES
('vvvvvvvv-vvvv-vvvv-vvvv-vvvvvvvvvvvv', 'hhhhhhhh-hhhh-hhhh-hhhh-hhhhhhhhhhhh', 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', '2024-01-20', '10:00:00', 'completed', 'Regular heart checkup'),
('wwwwwwww-wwww-wwww-wwww-wwwwwwwwwwww', 'iiiiiiii-iiii-iiii-iiii-iiiiiiiiiiii', 'cccccccc-cccc-cccc-cccc-cccccccccccc', '2024-01-21', '14:30:00', 'scheduled', 'Diabetes follow-up'),
('xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx', 'jjjjjjjj-jjjj-jjjj-jjjj-jjjjjjjjjjjj', 'dddddddd-dddd-dddd-dddd-dddddddddddd', '2024-01-22', '11:15:00', 'scheduled', 'Knee pain consultation');

-- 7. Insert Medical Records
INSERT INTO medical_records (record_id, patient_id, doctor_id, visit_date, diagnosis, symptoms, treatment, prescription, vital_signs, notes, follow_up_date) VALUES
('yyyyyyyy-yyyy-yyyy-yyyy-yyyyyyyyyyyy', 'hhhhhhhh-hhhh-hhhh-hhhh-hhhhhhhhhhhh', 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', '2024-01-20', 'Hypertension', 'High blood pressure, occasional headaches', 'Lifestyle modifications and medication', 'Lisinopril 10mg daily, Amlodipine 5mg daily', '{"blood_pressure": "140/90", "heart_rate": 72, "temperature": 98.6, "weight": "68kg"}', 'Patient advised to reduce salt intake and exercise regularly', '2024-04-20'),
('zzzzzzzz-zzzz-zzzz-zzzz-zzzzzzzzzzzz', 'iiiiiiii-iiii-iiii-iiii-iiiiiiiiiiii', 'cccccccc-cccc-cccc-cccc-cccccccccccc', '2024-01-15', 'Diabetes Type 2', 'Increased thirst, frequent urination', 'Diabetes management and monitoring', 'Metformin 500mg twice daily', '{"blood_pressure": "130/85", "heart_rate": 68, "temperature": 98.4, "blood_sugar": "180mg/dL"}', 'Patient educated about blood sugar monitoring', '2024-02-15');

-- 8. Insert Admissions
INSERT INTO admissions (admission_id, patient_id, room_id, admission_date, status, assigned_doctor_id, reason) VALUES
('aaaaaaaa-1111-1111-1111-111111111111', 'hhhhhhhh-hhhh-hhhh-hhhh-hhhhhhhhhhhh', 'pppppppp-pppp-pppp-pppp-pppppppppppp', '2024-01-18 10:30:00', 'discharged', 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'Hypertension monitoring'),
('bbbbbbbb-2222-2222-2222-222222222222', 'iiiiiiii-iiii-iiii-iiii-iiiiiiiiiiii', 'qqqqqqqq-qqqq-qqqq-qqqq-qqqqqqqqqqqq', '2024-01-19 14:00:00', 'admitted', 'cccccccc-cccc-cccc-cccc-cccccccccccc', 'Diabetes management');

-- 9. Insert Bills
INSERT INTO bills (bill_id, patient_id, admission_id, total_amount, paid_amount, status, items) VALUES
('cccccccc-3333-3333-3333-333333333333', 'hhhhhhhh-hhhh-hhhh-hhhh-hhhhhhhhhhhh', 'aaaaaaaa-1111-1111-1111-111111111111', 1250.00, 1250.00, 'paid', '[{"description": "Room charges (2 days)", "amount": 200.00}, {"description": "Consultation fees", "amount": 150.00}, {"description": "Lab tests", "amount": 300.00}, {"description": "Medications", "amount": 600.00}]'),
('dddddddd-4444-4444-4444-444444444444', 'iiiiiiii-iiii-iiii-iiii-iiiiiiiiiiii', 'bbbbbbbb-2222-2222-2222-222222222222', 800.00, 400.00, 'partial', '[{"description": "Room charges (1 day)", "amount": 200.00}, {"description": "Consultation fees", "amount": 150.00}, {"description": "Blood tests", "amount": 200.00}, {"description": "Medications", "amount": 250.00}]');

-- 10. Insert Inventory
INSERT INTO inventory (item_id, item_name, category, quantity, min_quantity, unit_price, supplier, expiry_date, storage_location) VALUES
('eeeeeeee-5555-5555-5555-555555555555', 'Paracetamol 500mg', 'Medication', 100, 20, 0.50, 'Pharma Corp Inc', '2025-12-31', 'Pharmacy Room A'),
('ffffffff-6666-6666-6666-666666666666', 'Bandages (sterile)', 'Medical Supplies', 200, 50, 2.00, 'MedSupply Inc', '2026-06-30', 'Storage Room B'),
('gggggggg-7777-7777-7777-777777777777', 'Syringe 5ml', 'Medical Supplies', 500, 100, 0.75, 'MedEquip Ltd', '2025-09-30', 'Storage Room A'),
('hhhhhhhh-8888-8888-8888-888888888888', 'Insulin Vials', 'Medication', 50, 10, 25.00, 'Diabetes Care Corp', '2024-08-15', 'Refrigerator Unit 1');

-- 11. Insert Prescriptions
INSERT INTO prescriptions (prescription_id, record_id, medication_name, dosage, frequency, duration, instructions, prescribed_date) VALUES
('iiiiiiii-9999-9999-9999-999999999999', 'yyyyyyyy-yyyy-yyyy-yyyy-yyyyyyyyyyyy', 'Lisinopril', '10mg', 'Once daily', '30 days', 'Take in the morning with food', '2024-01-20'),
('jjjjjjjj-0000-0000-0000-000000000000', 'yyyyyyyy-yyyy-yyyy-yyyy-yyyyyyyyyyyy', 'Amlodipine', '5mg', 'Once daily', '30 days', 'Take in the evening', '2024-01-20'),
('kkkkkkkk-1111-1111-1111-111111111111', 'zzzzzzzz-zzzz-zzzz-zzzz-zzzzzzzzzzzz', 'Metformin', '500mg', 'Twice daily', '30 days', 'Take with meals', '2024-01-15');

-- Create useful views

-- View for appointment details
CREATE VIEW appointment_details AS
SELECT 
    a.appointment_id,
    a.appointment_date,
    a.appointment_time,
    a.status,
    a.reason,
    a.notes,
    p.patient_id,
    p.first_name AS patient_first_name,
    p.last_name AS patient_last_name,
    p.phone_number AS patient_phone,
    p.email AS patient_email,
    s.staff_id AS doctor_id,
    s.first_name AS doctor_first_name,
    s.last_name AS doctor_last_name,
    s.specialization,
    s.department
FROM appointments a
JOIN patients p ON a.patient_id = p.patient_id
JOIN staff s ON a.doctor_id = s.staff_id;

-- View for patient medical history
CREATE VIEW patient_medical_history AS
SELECT 
    mr.record_id,
    mr.visit_date,
    p.patient_id,
    p.first_name AS patient_first_name,
    p.last_name AS patient_last_name,
    s.staff_id AS doctor_id,
    s.first_name AS doctor_first_name,
    s.last_name AS doctor_last_name,
    s.specialization,
    mr.diagnosis,
    mr.symptoms,
    mr.treatment,
    mr.prescription,
    mr.vital_signs,
    mr.follow_up_date
FROM medical_records mr
JOIN patients p ON mr.patient_id = p.patient_id
JOIN staff s ON mr.doctor_id = s.staff_id;

-- View for room occupancy
CREATE VIEW room_occupancy AS
SELECT 
    r.room_id,
    r.room_number,
    r.room_type,
    r.capacity,
    r.current_occupancy,
    r.is_available,
    d.department_name,
    COUNT(a.admission_id) as active_admissions
FROM rooms r
LEFT JOIN departments d ON r.department_id = d.department_id
LEFT JOIN admissions a ON r.room_id = a.room_id AND a.status = 'admitted'
GROUP BY r.room_id, r.room_number, r.room_type, r.capacity, r.current_occupancy, r.is_available, d.department_name;

-- View for staff details
CREATE VIEW staff_details AS
SELECT 
    s.staff_id,
    s.first_name,
    s.last_name,
    s.date_of_birth,
    s.gender,
    s.phone_number,
    s.specialization,
    s.qualification,
    s.experience_years,
    s.department,
    s.salary,
    s.hire_date,
    s.is_active,
    u.email,
    u.role
FROM staff s
JOIN users u ON s.user_id = u.user_id;

-- View for patient details with user info
CREATE VIEW patient_details AS
SELECT 
    p.patient_id,
    p.first_name,
    p.last_name,
    p.date_of_birth,
    p.gender,
    p.phone_number,
    p.email,
    p.address,
    p.emergency_contact_name,
    p.emergency_contact_phone,
    p.blood_type,
    p.allergies,
    p.medical_history,
    u.user_id,
    u.role,
    u.is_active
FROM patients p
JOIN users u ON p.user_id = u.user_id;

-- Insert Admin Staff Record
INSERT INTO staff (staff_id, user_id, first_name, last_name, date_of_birth, gender, phone_number, specialization, qualification, experience_years, department, salary, hire_date) VALUES
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '11111111-1111-1111-1111-111111111111', 'System', 'Administrator', '1980-01-01', 'Male', '+1-555-0001', 'Hospital Administration', 'MBA in Healthcare Management', 10, 'Administration', 100000.00, '2020-01-01');

-- Display completion message
SELECT 'Hospital Management System database created successfully!' as message;